FUNCTION_NAME = "getImpactedNetwork"
