

import json
import requests
import json
import logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)
def lambda_handler(event, context):
    # TODO implement
    url_fetch = 'http://172.16.36.156:80/get'
    
    r = requests.post(url = url_fetch, data = json.dumps(event))
    
    return json.loads(r.text)
