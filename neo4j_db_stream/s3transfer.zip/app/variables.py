FUNCTION_NAME = "persistEventInGraphDb"
